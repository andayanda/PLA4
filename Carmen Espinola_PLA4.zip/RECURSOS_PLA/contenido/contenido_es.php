<?php
//del header
$h1 ="Instituto de Estudios Modernos";
//de la pagina de contacto de la
$titulo ="LOCALIZACIÓN DEL CENTRO Y CONTACTO";
$subtitulo= "CONTACTO";
$campos_obligatorios="Los campos marcados con * son obligatorios.";
$label_Nombre="Nombre: *";
$label_Email="Email: *";
$label_Telefono="Teléfono:";
$label_Mensaje="Mensaje: *";
$lgpd="En cumplimiento de la Ley Orgánica 15/1999, de 13 de diciembre, de Protección de Datos de Carácter Personal (LOPD), le informamos que los datos de carácter personal que usted nos comunique mediante este formulario de contacto serán confidenciales y, bajo ningún concepto, serán transmitidos a terceras personas.";
$acepto_lgpd= "He leido y acepto la política de privacidad:";
$placeholder_1= "Introduzca aquí su pregunta o comentario";
$leyenda="Ver aquí";
//del footer
$comparte ="Comparte en:";
//del nav
$inicio ="LA ESCUELA";
$seccion1="CURSOS Y HORARIOS";
$seccion2="SITUACIÓN Y CONTACTO";
?>