<?php
//del header
$h1 ="Institut d'Estudis Moderns";
//de la pagina de contacto de la
$titulo ="LOCALITZACIÓ DEL CENTRE I CONTACTE";
$subtitulo= "CONTACTE";
$campos_obligatorios="Els camps marcats amb * son obligatoris.";
$label_Nombre="Nom: *";
$label_Email="Email: *";
$label_Telefono="Telèfon:";
$label_Mensaje="Missatge: *";
$lgpd="En compliment de la LLei Orgànica 15/1999, de 13 de decembre, de Protecció de Dades de Caràcter Personal (LOPD), l'informem que les dades de caràcter personal que vostè ens comuniqui mitjançant aquest formulari de contacte seràn confidencials i, sota cap concepte seràn transmeses a terceres persones.";
$acepto_lgpd= "He llegit i accepto la política de privacitat:";
$placeholder_1= "Introdueixi aquí la seva pregunta o comentari";
$leyenda="Veure aquí";
//del footer
$comparte ="Comparteix a ";
//del nav
$inicio ="L'ESCOLA";
$seccion1="CURSOS I HORARIS ";
$seccion2="SITUACIÓ I CONTACTE";
?>











form.js
-------

Nom
Email
Si us plau introdueixi una adreça de correu electrónic vàlida
Missatge
Es obligatori acceptar la normativa de privacitat
Si us plau revisi les següents dades
